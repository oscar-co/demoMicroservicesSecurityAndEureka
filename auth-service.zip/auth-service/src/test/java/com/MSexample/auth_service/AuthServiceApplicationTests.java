package com.MSexample.auth_service;

import org.junit.jupiter.api.Test;

//@SpringBootTest
class AuthServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
